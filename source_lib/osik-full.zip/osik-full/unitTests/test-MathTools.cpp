#include <osik-control/math-tools.hpp>
#include <iostream>


int main(int argc, char *argv[])
{
  // Euler angles

  Eigen::Vector3d rpy1, rpy2;
  Eigen::Matrix3d R1, R2;
  rpy1 << 0.11, -0.25, 0.32;

  R1 = RPYToRotation(rpy1);
  rpy2 = rotationToRPY(R1);
  
  std::cout << "RPY1: " << rpy1.transpose() << std::endl;
  std::cout << "Rot 1:\n" << R1 << std::endl;
  std::cout << "RPY2: " << rpy2.transpose() << std::endl;

  // Axis/Angle representation

  Eigen::Vector3d aa1, aa2;
  //aa1 << 0.5235, 0, 0;
  aa1 << 0.001, 0.0, 0.0;
  
  R1 = axisAngleToRotation(aa1);
  aa2 = rotationToAxisAngle(R1);

  std::cout << "\nAxis/Angle1: " << aa1.transpose() << std::endl;
  std::cout << "Rot 1:\n" << R1 << std::endl;
  std::cout << "Axis/Angle2: " << aa2.transpose() << std::endl;

  return 0;
}
