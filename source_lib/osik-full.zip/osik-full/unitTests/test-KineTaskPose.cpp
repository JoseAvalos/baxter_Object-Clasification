#include <robot-model/robot-model.hpp>

#include <osik-control/kine-task.hpp>
#include <osik-control/kine-task-pose.hpp>


// Specific to the humanoid_example
const unsigned int RWRIST = 29;
const unsigned int LWRIST = 22;
const unsigned int RANKLE = 12;
const unsigned int LANKLE = 6;
const unsigned int ROOT = 0;

using namespace osik;


int main(int argc, char **argv)
{
  // Parse the robot urdf
  std::string model_name = "humanoid_example.urdf";
  RobotModel* robot = new RobotModel();
  if (!robot->loadURDF(model_name))
    return -1;
  
  // Initialize the joint configuration
  unsigned int ndof = robot->ndof();
  Eigen::VectorXd q = Eigen::VectorXd::Zero(ndof);
  q.head(6) << 0, 0, 0.6535, 0, 0, 0;

  // *************
  // Position Task
  // *************
  KineTask* taskrh = new KineTaskPose(robot, RWRIST, "position");
  taskrh->setGain(1.0);
  std::cout << "Constant gain is: " << taskrh->getGain() << std::endl;

  Eigen::VectorXd P1, P2;
  taskrh->getSensedValue(q, P1);
  std::cout << "Right wrist - sensed value: " << P1.transpose() << std::endl;
  P1[0] = P1[0] - 0.10;
  P1[1] = P1[1] - 0.10;
  P1[2] = P1[2] + 0.20;
  taskrh->setDesiredValue(P1);
  taskrh->getDesiredValue(P2);
  std::cout << "Right wrist des value: " << P2.transpose() << std::endl;

  Eigen::MatrixXd J;
  taskrh->getJacobian(q, J);
  std::cout << "Jacobian:\n" << J << std::endl;


  // // Orientation task (TODO)
  // KinematicTask* tasklh = new PoseTask(robot, LWRIST, "position");
  // tasklh->setGain(1.0);
  // Eigen::VectorXd Plwrist;
  // tasklh->getSensedValue(q, Plwrist);
  // Plwrist[0] = Plwrist[0] - 0.10;
  // Plwrist[1] = Plwrist[1] + 0.10;
  // Plwrist[2] = Plwrist[2] + 0.15;
  // tasklh->setDesiredValue(Plwrist);

  
  return 0;
}


