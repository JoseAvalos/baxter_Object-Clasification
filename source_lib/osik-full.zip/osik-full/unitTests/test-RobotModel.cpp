#include <robot-model/robot-model.hpp>


// Specific to the humanoid_example
const unsigned int RWRIST = 29;
const unsigned int LWRIST = 22;
const unsigned int RANKLE = 12;
const unsigned int LANKLE = 6;
const unsigned int ROOT = 0;


int main(int argc, char **argv)
{

  std::string model_name = "humanoid_example.urdf";

  RobotModel* robot = new RobotModel();
  if (!robot->loadURDF(model_name))
    return -1;

  // Check number of degrees of freedom
  unsigned int ndof = robot->ndof();
  unsigned int ndof_actuated = robot->ndof_actuated();
  std::cout << "N dof: " << ndof << std::endl;
  std::cout << "N dof actuated: " << ndof_actuated << std::endl;
  if (!(ndof==35) || !(ndof_actuated==29))
  {
    std::cout << "ERROR: ndof does not match ... exiting" << std::endl;
    return -1;
  }

  // Joint names and joint limits
  std::vector<std::string> jnames;
  std::vector<double> qmin, qmax, dqmax;
  jnames = robot->jointNames();
  qmax   = robot->jointMaxAngularLimits();
  qmin   = robot->jointMinAngularLimits();
  dqmax  = robot->jointVelocityLimits();
  for (unsigned int i=0; i<ndof_actuated; ++i)
  {
    std::cout << "Joint " << jnames[i] << " with limits [" << qmin[i] << ", " 
              << qmax[i] << "] and vel max: " << dqmax[i] << std::endl;
  }

  // Link names
  std::vector<std::string> link_names;
  std::vector<unsigned int> link_ids;
  robot->linkNames(link_names, link_ids);
  for (unsigned int i=0; i<link_names.size(); ++i)
    std::cout << "Link name: " << link_names[i] << " with ID: " << link_ids[i]
              << std::endl;

  // Forward kinematics: position
  Eigen::VectorXd q = Eigen::VectorXd::Zero(ndof);
  // Change floating base: x,y,z,rx,ry,rz (roll, pitch, yaw)
  q.head(6) << 0, 0, 0.6535, 0, 0, 0;
  // q.head(6) << 0, 0, 0.6535, 0, 0, M_PI/2;
  Eigen::Vector3d pos;
  pos = robot->linkPosition(q, ROOT, Eigen::Vector3d::Zero());
  std::cout << "Root position: " << pos.transpose() << std::endl;
  pos = robot->linkPosition(q, RWRIST, Eigen::Vector3d::Zero());
  std::cout << "Right wrist: " << pos.transpose() << std::endl;
  pos = robot->linkPosition(q, LWRIST, Eigen::Vector3d::Zero());
  std::cout << "Left wrist: " << pos.transpose() << std::endl;
  pos = robot->linkPosition(q, RANKLE, Eigen::Vector3d::Zero());
  std::cout << "Right ankle: " << pos.transpose() << std::endl;
  pos = robot->linkPosition(q, LANKLE, Eigen::Vector3d::Zero());
  std::cout << "Left ankle: " << pos.transpose() << std::endl;

  // When free floating = 0 0 0 0 0 0:
  // - Root position: 0     0     0
  // - Right wrist:   0 -0.21 -0.16
  // - Left wrist:    0  0.21 -0.16
  // - Right ankle:   0 -0.09 -0.6535
  // - Left ankle:    0  0.09 -0.6535

  // When free floating = 0, 0, 0.6535, 0, 0, 0
  // - Root position: 0     0 0.6535
  // - Right wrist:   0 -0.21 0.4935
  // - Left wrist:    0  0.21 0.4935
  // - Right ankle:   0 -0.09      0
  // - Left ankle:    0  0.09      0

  // When free floating = 0, 0, 0.6535, 0, 0, M_PI/2
  // - Root position:    0   0  0.6535
  // - Right wrist:    0.21  0  0.4935
  // - Left wrist:    -0.21  0  0.4935
  // - Right ankle:    0.09  0       0
  // - Left ankle:    -0.09  0       0

  // Forward Kinematics: Orientation
  q = Eigen::VectorXd::Zero(ndof);
  q.head(6) << 0, 0, 0.6535, 0, 0, M_PI/2;
  // q.head(6) << 0, 0, 0.6535, 0, 0, M_PI/2;
  Eigen::Vector3d rpy;
  rpy = robot->linkOrientation(q, ROOT);
  std::cout << "Root orientation: " << rpy.transpose() << std::endl;
  rpy = robot->linkOrientation(q, RWRIST);
  std::cout << "Right wrist orientation: " << rpy.transpose() << std::endl;
  rpy = robot->linkOrientation(q, LWRIST);
  std::cout << "Left wrist orientation: " << rpy.transpose() << std::endl;
  


  // Jacobian
  Eigen::MatrixXd Jac;
  q.head(6) << 0, 0, 0.6535, 0, 0, 0;
  Jac = robot->linearJacobian(q, RWRIST, Eigen::Vector3d::Zero());
  std::cout << "Jacobian of rwrist:\n" << Jac << std::endl;

  return 0;
}


