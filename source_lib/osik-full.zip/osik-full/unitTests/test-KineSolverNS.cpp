#include <robot-model/robot-model.hpp>

#include <osik-control/math-tools.hpp>
#include <osik-control/kine-task-pose.hpp>
#include <osik-control/kine-solver-NS.hpp>
#include <osik-control/kine-task.hpp>


// Specific to the humanoid_example
const unsigned int RWRIST = 29;
const unsigned int LWRIST = 22;
const unsigned int RANKLE = 12;
const unsigned int LANKLE = 6;
const unsigned int ROOT = 0;

using namespace osik;


int main(int argc, char **argv)
{
  // Parse the robot urdf
  std::string model_name = "humanoid_example.urdf";
  RobotModel* robot = new RobotModel();
  if (!robot->loadURDF(model_name))
    return -1;

  // Initialize the joint configuration
  unsigned int ndof = robot->ndof();
  Eigen::VectorXd q = Eigen::VectorXd::Zero(ndof);
  q.head(6) << 0, 0, 0.6535, 0, 0, 0;

  // Sampling time
  unsigned int f = 10;
  double dt = static_cast<double>(1.0/f);

  KineSolverNS solver(robot, q, dt);
  
  KineTask* taskrh = new KineTaskPose(robot, RWRIST, "position");
  KineTask* tasklh = new KineTaskPose(robot, LWRIST, "position");
  taskrh->setGain(1.0);
  tasklh->setGain(1.0);

  Eigen::VectorXd Prwrist;
  taskrh->getSensedValue(q, Prwrist);
  Prwrist[0] = Prwrist[0] - 0.10;
  Prwrist[1] = Prwrist[1] - 0.10;
  Prwrist[2] = Prwrist[2] + 0.15;
  taskrh->setDesiredValue(Prwrist);

  Eigen::VectorXd Plwrist;
  tasklh->getSensedValue(q, Plwrist);
  Plwrist[0] = Plwrist[0] - 0.10;
  Plwrist[1] = Plwrist[1] + 0.10;
  Plwrist[2] = Plwrist[2] + 0.15;
  tasklh->setDesiredValue(Plwrist);

  solver.pushTask(taskrh);
  solver.pushTask(tasklh);

  Eigen::VectorXd qcontrol;

  solver.getPositionControl(q, qcontrol);
  q = qcontrol;

  std::cout << q.transpose() << std::endl;
  
  return 0;
}


