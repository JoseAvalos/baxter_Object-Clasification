#include <osik-control/kine-solver-WQP.hpp>
#include <osik-control/constants.hpp>


namespace osik{


KineSolverWQP::KineSolverWQP(RobotModel* rmodel, 
                             const Eigen::VectorXd& qinit, 
                             const double& dt)
  :
  KineSolver(rmodel, qinit, dt)
{
  qpOptions_.setToMPC();
  qpOptions_.printLevel = qpOASES::PL_LOW;

}

void KineSolverWQP::setJointLimits(const std::vector<double>& qmin,
                                   const std::vector<double>& qmax,
                                   const std::vector<double>& dqmax)
{
  qmin_.resize(rmodel_->ndof());
  qmax_.resize(rmodel_->ndof());
  dqmax_.resize(rmodel_->ndof());

  unsigned int jinit=0;
  
  // If the robot has floating base, add high limit values for them
  if (rmodel_->hasFloatingBase())
  {
    jinit=6;
    for (unsigned int i=0; i<6; ++i)
    {
      qmin_[i] = -INFTY;
      qmax_[i] =  INFTY;
      dqmax_[i] = INFTY;
    }
  }
  // Joint limits for the actuated joints
  for (unsigned int i=jinit; i<qmin_.size(); ++i)
  {
    qmin_[i]  = qmin[i-jinit];
    qmax_[i]  = qmax[i-jinit];
    dqmax_[i] = dqmax[i-jinit];
  }
  
}



void KineSolverWQP::getPositionControl(const Eigen::VectorXd& q,
                                       Eigen::VectorXd& qdes)
{
  //std::cout << "enter0" << std::endl;
  // Fail if called without tasks
  if (taskStack_.size()==0){
    std::cerr << "Cannot get control without tasks ... "
              << "keeping previous configuration" << std::endl;
    qdes = q;
    return;
  }

  // Fail if no joint limits set
  if ( (qmin_.size()==0) || (qmax_.size()==0) ){
    std::cerr << "Joint limits are not set! ..."
              << "keeping previous configuration" << std::endl;
    qdes = q;
    return;
  }
    
  Eigen::VectorXd dq, de, p, eint;
  Eigen::MatrixXd J;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic,Eigen::RowMajor> W;
  double weight;
  //std::cout << "enter1" << std::endl;
  // Adding regularization term
  W = Eigen::MatrixXd::Identity(q.size(), q.size());
  p = Eigen::VectorXd::Zero(q.size());

  for (unsigned int i=0; i<taskStack_.size(); ++i)
  {
    taskStack_[i]->getJacobian(q, J);
    taskStack_[i]->getDerivError(q, de);
    //taskStack_[i]->getIntegralError(q, eint);
    weight = taskStack_[i]->getWeight();

    W = W + weight*J.transpose()*J;
    //p = p - 2*weight*J.transpose()*(de+eint);
    p = p - 2*weight*J.transpose()*(de);
  }
  // std::cout << "enter2" << std::endl;
  unsigned int nV = rmodel_->ndof();

  double *H = W.data();
  double *g = p.data();

  double *lb = new double[nV];
  double *ub = new double[nV];
  double ltmp, utmp;
  //for (unsigned int i=0; i<ndof_; ++i)
  for (unsigned int i=0; i<nV; ++i)
  {
    ltmp = (1.0/dt_)*(qmin_[i]-q[i]);
    utmp = (1.0/dt_)*(qmax_[i]-q[i]);
    lb[i] = ltmp > -dqmax_[i] ? ltmp : -dqmax_[i];
    ub[i] = utmp < dqmax_[i] ? utmp : dqmax_[i];
  }

  qpOASES::QProblemB qp(nV);
  qp.setOptions(qpOptions_);
  int nWSR = 10;  // Max number of working set recalculations
  qp.init(H, g, lb, ub, nWSR, 0);
  
  double dqArray[nV];
  qp.getPrimalSolution(dqArray);

  //dq.resize(ndof_);
  dq.resize(nV);
  //for (unsigned int i=0; i<ndof_; ++i)
  for (unsigned int i=0; i<nV; ++i)
    dq[i] = dqArray[i];

  qdes = qdes_ + dt_*dq; 
  qdes_ = qdes;

}

}
