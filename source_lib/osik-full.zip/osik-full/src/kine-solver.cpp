#include <osik-control/kine-solver.hpp>


namespace osik{

KineSolver::KineSolver(RobotModel* model,
                       const Eigen::VectorXd& qinit, 
                       const double& dt)
  :
  rmodel_(model),
  dt_(dt),
  qdes_(qinit)
{
  taskStack_.clear();
  ndof_ = model->ndof();
}
  
  
KineSolver::~KineSolver()
{
  delete rmodel_;
}


void KineSolver::getTaskStack(std::vector< KineTask* >& stack_tasks)
{
  stack_tasks = taskStack_;
}


void KineSolver::pushTask(KineTask* task)
{
  taskStack_.push_back(task);
}


void KineSolver::popTask()
{
  taskStack_.pop_back();
}

void KineSolver::removeTask(const std::string& taskName)
{
  for (unsigned int i=0; i<taskStack_.size(); ++i)
  {
    if (taskName.compare(taskStack_[i]->getName())==0)
    {
      taskStack_.erase(taskStack_.begin()+i);
      break;
    }
  }
}


}
