#include <robot-model/robot-model.hpp>
#include <osik-control/math-tools.hpp>

#include <urdf_model/model.h>
#include <urdf_parser/urdf_parser.h>

#include <rbdl/addons/urdfreader/urdfreader.h>
#include <stack>



RobotModel::RobotModel()
  : 
  rmodel_(new RigidBodyDynamics::Model()),
  has_floating_base_(true),
  jnames_(0),
  qmin_(0),
  qmax_(0),
  dqmax_(0)
{
}


RobotModel::~RobotModel()
{
  delete rmodel_;
}


bool RobotModel::loadURDF(const std::string& model_name,
                          const bool& has_floating_base)
{
  has_floating_base_ = has_floating_base;

  bool verbose = false;

  if (!RigidBodyDynamics::Addons::URDFReadFromFile(model_name.c_str(), 
                                                   rmodel_, verbose)) 
  {
    return false;
  }
  else
  {
    std::cout << "Loaded: " << model_name << std::endl;
  }

  /*
   * Get joint names and joint limits from urdf (rbdl does not provide them!)
   */
  jnames_.clear();
  qmin_.clear();
  qmax_.clear();
  dqmax_.clear();

  typedef boost::shared_ptr<urdf::Link> LinkPtr;
  typedef boost::shared_ptr<urdf::Joint> JointPtr;

  boost::shared_ptr<urdf::ModelInterface> 
    urdf_model = urdf::parseURDFFile(model_name);

  std::map<std::string, LinkPtr > link_map;
  link_map = urdf_model->links_;
  
  std::stack<LinkPtr > link_stack;
  std::stack<int> joint_index_stack;
  
  // Add the bodies in a depth-first order of the model tree
  link_stack.push (link_map[(urdf_model->getRoot()->name)]);
  
  if (link_stack.top()->child_joints.size() > 0) {
    joint_index_stack.push(0);
  }
  
  while (link_stack.size() > 0) {
    LinkPtr cur_link = link_stack.top();
    unsigned int joint_idx = joint_index_stack.top();
    
    if (joint_idx < cur_link->child_joints.size()) {
      JointPtr cur_joint = cur_link->child_joints[joint_idx];
      
      // Increment joint index
      joint_index_stack.pop();
      joint_index_stack.push(joint_idx+1);
      
      link_stack.push (link_map[cur_joint->child_link_name]);
      joint_index_stack.push(0);

      int i = 0;
      //if (cur_joint->type == 1 || cur_joint->type == 2)
      if (cur_joint->type == urdf::Joint::REVOLUTE || 
          cur_joint->type == urdf::Joint::CONTINUOUS)
      {
        // std::cout << "joint: " << cur_joint->name << std::endl;
        jnames_.push_back(cur_joint->name);
        // For revolute joints
        if (cur_joint->type == 1) 
        {
          qmin_.push_back(cur_joint->limits->lower);
          qmax_.push_back(cur_joint->limits->upper);
          dqmax_.push_back(cur_joint->limits->velocity);
        }
        // *************************************************
        // For continuous joints, set arbitrarily big values
        // *************************************************
        else {
          qmin_.push_back(-20.0);
          qmax_.push_back(20.0);
          dqmax_.push_back(100.0);
        }
        i++;
      }
      else if (cur_joint->type == urdf::Joint::FLOATING) 
      {
        std::cout << "Found floating joint in URDF model (joint " << i++ 
                  << ")" << "... \n  -> Not supported. Unknown results!";
        std::cout << "Please change the \"floating\" joint to \"fixed\" in "
          "the URDF MOdel" << std::endl;
        return false;
      }
      else if (cur_joint->type == urdf::Joint::PRISMATIC)
      {
        std::cout << "Not supported joint: PRISMATIC" << std::endl;
        return false;
      }
    } 
    else 
    {
      link_stack.pop();
      joint_index_stack.pop();
    }
  }
  return true;
}


unsigned int RobotModel::ndof() 
  const
{
  if (has_floating_base_)
    return 6 + rmodel_->dof_count;
  else
    return rmodel_->dof_count;
}


unsigned int RobotModel::ndof_actuated() 
  const
{
  return rmodel_->dof_count;
}


std::vector<std::string> RobotModel::jointNames() 
  const
{
  return jnames_;
}


std::vector<double> RobotModel::jointMaxAngularLimits() 
  const
{
  return qmax_;
}


std::vector<double> RobotModel::jointMinAngularLimits() 
  const
{
  return qmin_;
}


std::vector<double> RobotModel::jointVelocityLimits() 
  const
{
  return dqmax_;
}


void RobotModel::linkNames(std::vector<std::string>& link_names, 
                              std::vector<unsigned int>& link_ids)
  const
{
  link_names.clear();
  link_ids.clear();

  std::map< std::string, unsigned int > bodymap = rmodel_->mBodyNameMap;
  for (std::map< std::string, unsigned int >::iterator it=bodymap.begin();
       it!=bodymap.end(); ++it)
  {
    link_names.push_back(it->first);
    link_ids.push_back(it->second); 
 }
}


bool RobotModel::hasFloatingBase() 
  const
{
  return has_floating_base_;
}


Eigen::Vector3d RobotModel::linkPosition(const Eigen::VectorXd& q, 
                                         const unsigned int& link_number,
                                         const Eigen::Vector3d& local_pos)
  const
{
  Eigen::Vector3d lpos;
  if (has_floating_base_)
  {
    lpos = CalcBodyToBaseCoordinates(*rmodel_, q.tail(this->ndof_actuated()), 
                                     link_number, local_pos, true);
    // Transform to the world frame (using the floating base transformation)
    Eigen::Matrix3d Rbase;
    Rbase = RPYToRotation(q.segment(3,3));
    lpos = Rbase*lpos + q.head(3);
  }
  else
    lpos = CalcBodyToBaseCoordinates(*rmodel_, q, link_number, 
                                     local_pos, true);
  return lpos;
}


Eigen::Vector3d RobotModel::linkOrientation(const Eigen::VectorXd& q,
                                            const unsigned int& link_number) 
  const
{
  Eigen::Vector3d rpy;
  Eigen::Matrix3d Rlink;
  if(has_floating_base_)
  {
    Rlink = CalcBodyWorldOrientation(*rmodel_, q.tail(this->ndof_actuated()),
                                    link_number, true);
    Eigen::Matrix3d Rbase;
    Rbase = RPYToRotation(q.segment(3,3));
    Rlink = Rbase*Rlink;
  }
  else
    Rlink = CalcBodyWorldOrientation(*rmodel_, q, link_number, true);

  rpy = rotationToRPY(Rlink);
  return rpy;
}


Eigen::VectorXd RobotModel::linkPose(const Eigen::VectorXd& q,
                                     const unsigned int& link_number,
                                     const Eigen::Vector3d& local_pos) 
  const
{
  Eigen::VectorXd lpose;
  Eigen::Matrix3d Rlink;
  lpose.resize(6);

  if(has_floating_base_)
  {
    lpose.head(3) = CalcBodyToBaseCoordinates(*rmodel_, 
                                              q.tail(ndof_actuated()),
                                              link_number, local_pos, true);
    Rlink = CalcBodyWorldOrientation(*rmodel_, q.tail(ndof_actuated()),
                                     link_number, true);
    //std::cout << "Rlink:\n" << Rlink << std::endl;
    // Transform to the world frame (using the floating base transformation)
    Eigen::Matrix3d Rbase;
    Rbase = RPYToRotation(q.segment(3,3));
    //std::cout << "BASE:\n " << Rbase << std::endl;
    lpose.head(3) = Rbase*lpose.head(3) + q.head(3);
    Rlink = Rbase*Rlink;
    //Rlink = Rlink*Rbase;
  }
  else
  {
    lpose.head(3) = CalcBodyToBaseCoordinates(*rmodel_, q, link_number, 
                                              local_pos, true);
    Rlink = CalcBodyWorldOrientation(*rmodel_, q, link_number, true);
  }
  lpose.tail(3) = rotationToRPY(Rlink);
  //std::cout << "pose: " << lpose.transpose() << std::endl;
  
  return lpose;
}


Eigen::MatrixXd RobotModel::linearJacobian(const Eigen::VectorXd& q, 
                                           const unsigned int& link_number,
                                           const Eigen::Vector3d& local_pos)
  const
{ 
  Eigen::MatrixXd J;

  if (has_floating_base_)
  {
    Eigen::Vector3d xbody, xbase;
    Eigen::Matrix3d R;

    R = RPYToRotation(q.segment(3,3));
    xbody = CalcBodyToBaseCoordinates(*rmodel_, q.tail(this->ndof_actuated()), 
                                      link_number, local_pos, true);
    xbase = CalcBodyToBaseCoordinates(*rmodel_, q.tail(this->ndof_actuated()), 
                                      0, local_pos, true);
    // xbody = R*xbody + q.head(3);
    // xbase = R*xbase + q.head(3);

    Eigen::MatrixXd Jxyz;
    Jxyz.resize(3,this->ndof_actuated());
    Jxyz.setZero(); // VERY IMPORTANT FOR THE JACOBIAN!!!
    CalcPointJacobian(*rmodel_, q.tail(this->ndof_actuated()), 
                      link_number, local_pos, Jxyz);

    J.resize(3, this->ndof());
    //J.leftCols(3) = Eigen::Matrix3d::Identity();
    J.leftCols(3) = R;
    //J.middleCols(3,3) = skew(xbase-xbody); // If using the two commnted lines
    J.middleCols(3,3) = skew(R*(xbase-xbody));
    J.rightCols(this->ndof_actuated()) = R*Jxyz;
  }
  else
  {
    J.resize(3, this->ndof());
    J.setZero(); // VERY IMPORTANT FOR THE JACOBIAN!!!
    CalcPointJacobian(*rmodel_, q, link_number, local_pos, J, true);
  }
  return J;
}


Eigen::MatrixXd RobotModel::angularJacobian(const Eigen::VectorXd& q, 
                                            const unsigned int& link_number)
  const
{ 
  Eigen::MatrixXd J;

  if (has_floating_base_)
  {
    Eigen::Matrix3d R;
    R = RPYToRotation(q.segment(3,3));
    
    Eigen::MatrixXd Jang;
    Jang.resize(6, this->ndof_actuated());
    Jang.setZero();
    CalcBodySpatialJacobian(*rmodel_, q, link_number, Jang);
    // TODO: check that this is indeed the orientation jacobian

    J.resize(3, this->ndof());
    J.leftCols(3) = Eigen::Matrix3d::Zero();
    //J.middleCols(3,3) = Eigen::Matrix3d::Identity();
    J.middleCols(3,3) = R;
    J.rightCols(this->ndof_actuated()) = R*Jang.topRows(3);
  }
  else
  {
    J.resize(6, this->ndof());
    J.setZero();
    CalcBodySpatialJacobian(*rmodel_, q, link_number, J);
    // TODO: check that this is indeed the orientation jacobian
    J.conservativeResize(3, this->ndof()); 
  }
  return J;
}


Eigen::MatrixXd RobotModel::geometricJacobian(const Eigen::VectorXd& q, 
                                              const unsigned int& link_number,
                                              const Eigen::Vector3d& local_pos)
  const
{
  Eigen::MatrixXd J, Jtmp;

  if (has_floating_base_)
  {
    J.resize(6, this->ndof());
    
    Eigen::Vector3d xbody, xbase;
    Eigen::Matrix3d R;
    R = RPYToRotation(q.segment(3,3));

    xbody = CalcBodyToBaseCoordinates(*rmodel_, q.tail(this->ndof_actuated()), 
                                      link_number, local_pos, true);
    xbase = CalcBodyToBaseCoordinates(*rmodel_, q.tail(this->ndof_actuated()), 
                                      0, local_pos, true);
    Eigen::MatrixXd Jtmp;
    Jtmp.resize(3,this->ndof_actuated());
    Jtmp.setZero(); // Important
    CalcPointJacobian(*rmodel_, q.tail(this->ndof_actuated()), 
                      link_number, local_pos, Jtmp);

    //J.leftCols(3) = Eigen::Matrix3d::Identity();
    J.topLeftCorner(3,3) = R;
    //J.middleCols(3,3) = skew(xbase-xbody); // If using the two commnted lines
    //J.middleCols(3,3) = skew(R*(xbase-xbody));
    J.block(0,3,3,3) = skew(R*(xbase-xbody));
    J.topRightCorner(3,this->ndof_actuated()) = R*Jtmp;

    Jtmp.resize(6, this->ndof_actuated());
    Jtmp.setZero();
    CalcBodySpatialJacobian(*rmodel_, q, link_number, Jtmp);
    // TODO: check that this is indeed the orientation jacobian

    J.bottomLeftCorner(3,3) = Eigen::Matrix3d::Zero();
    //J.middleCols(3,3) = Eigen::Matrix3d::Identity();
    //J.middleCols(3,3) = R;
    J.block(3,3,3,3) = R;
    J.bottomRightCorner(3,this->ndof_actuated()) = R*Jtmp.topRows(3);
  }
  else
  {
    J.resize(6, ndof());

    Jtmp.resize(3, ndof());
    Jtmp.setZero(); // Important!
    CalcPointJacobian(*rmodel_, q, link_number, local_pos, Jtmp, true);
    J.topRows(3) = Jtmp;

    Jtmp.resize(6, ndof());
    Jtmp.setZero(); // Important!
    CalcBodySpatialJacobian(*rmodel_, q, link_number, Jtmp, true);
    J.bottomRows(3) = Jtmp.topRows(3);
  }

  return J;
}
