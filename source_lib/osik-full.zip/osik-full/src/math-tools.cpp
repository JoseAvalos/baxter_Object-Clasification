#include <osik-control/math-tools.hpp>
#include <iostream>


void pinv(const Eigen::MatrixXd& matrix_in, 
          Eigen::MatrixXd& pseudo_inv, 
          const double& pinvtoler)
{
  Eigen::JacobiSVD<Eigen::MatrixXd> svd(matrix_in, Eigen::ComputeThinU | 
                                        Eigen::ComputeThinV);        
  Eigen::VectorXd singular_values;
  Eigen::VectorXd singular_values_inv;
  singular_values = svd.singularValues();
  singular_values_inv.setZero(singular_values.size());

  for (int w = 0; w < singular_values.size(); ++w)
    if( singular_values(w) > pinvtoler)
      singular_values_inv(w) = 1/singular_values(w);
  pseudo_inv = svd.matrixV() * singular_values_inv.asDiagonal() * 
    svd.matrixU().transpose();                 
  return;
}


Eigen::Matrix3d skew(const Eigen::Vector3d& w)
{
  Eigen::Matrix3d R;
  R(0,0) = 0.0;   R(0,1) = -w(2); R(0,2) = w(1);
  R(1,0) = w(2);  R(1,1) = 0.0;   R(1,2) = -w(0);
  R(2,0) = -w(1); R(2,1) = w(0);  R(2,2) = 0.0;
  return R;
}


Eigen::Matrix3d RPYToRotation(const Eigen::Vector3d& rpy)
{
  Eigen::Matrix3d res;
  res = rotationMatrix('z',rpy(2))*rotationMatrix('y',rpy(1))
    *rotationMatrix('x',rpy(0));
  return res;
}


Eigen::Vector3d rotationToRPY(const Eigen::Matrix3d& R)
{
  Eigen::Vector3d rpy;
  double m = sqrt(R(2,1)*R(2,1)+R(2,2)*R(2,2));
  rpy(1) = atan2(-R(2,0),m);

  // if (abs(rpy(1)-M_PI/2.0) < 0.001)
  // {
  //   rpy(0) = 0;
  //   rpy(2) = atan2(R(0,1), R(1,1));
  // }
  // else if (abs(rpy(1)+M_PI/2.0) < 0.001)
  // {
  //   rpy(0) = 0;
  //   rpy(2) = -atan2(R(0,1), R(1,1));
  // }
  // else
  // {
  //   rpy(0) = atan2(R(1,0), R(0,0));
  //   rpy(2) = atan2(R(2,1), R(2,2));
  // }

  if (abs(rpy(1)-M_PI/2.0) < 0.001)
  {
    rpy(2) = 0;
    rpy(0) = atan2(R(0,1), R(1,1));
  }
  else if (abs(rpy(1)+M_PI/2.0) < 0.001)
  {
    rpy(2) = 0;
    rpy(0) = -atan2(R(0,1), R(1,1));
  }
  else
  {
    rpy(2) = atan2(R(1,0), R(0,0));
    rpy(0) = atan2(R(2,1), R(2,2));
  }

  return rpy;
}


Eigen::Vector3d rotationToAxisAngle(const Eigen::Matrix3d& R)
{
  Eigen::Vector3d res;

  double costheta = 0.5*(R.trace()-1.0);
  double cmin, cmax, theta;
  cmin = costheta < 1.0 ? costheta : 1.0;
  cmax = cmin > -1.0 ? cmin : -1.0;
  theta = acos(cmax);
  //std::cout << "theta: " << fabs(theta) << std::endl;

  if (fabs(theta-M_PI) < 1e-5)
  {
    double xx = 0.5*(R(0,0)+1.0);
    double yy = 0.5*(R(1,1)+1.0);
    double zz = 0.5*(R(2,2)+1.0);
    if (xx < 0.0) xx = 0.0;
    if (yy < 0.0) yy = 0.0;
    if (zz < 0.0) zz = 0.0;
    res(0) = M_PI*sqrt(xx);
    res(1) = M_PI*sqrt(yy);
    res(2) = M_PI*sqrt(zz);
    double xy = R(0,1);
    double xz = R(0,2);
    double yz = R(1,2);
    if (res(0)>res(1))
    {
      if (res(0)>res(2)) {
        if (xy<0)  res(1) = -res(1);
        if (xz<0)  res(2) = -res(2);
      }
      else {
        if (yz<0) res(1) = -res(1);
        if (xz<0) res(0) = -res(0);
      }
    }
    else
    {
      if (res(1)>res(2)) {
        if (xy<0) res(0) = -res(0);
        if (yz<0) res(2) = -res(2);
      }
      else {
        if (yz<0) res(1) = -res(1);
        if (xz<0) res(0) = -res(0);
      }
    }
  }
  else
  {
    //std::cout << "here" << std::endl;
    // double alpha = 0.5;
    // if (abs(theta) > 1e-5)
    //   alpha = 0.5*theta/sin(theta);
    double alpha = 0.5*theta/sin(theta);
    if (fabs(theta) < 1e-5){
      //std::cout << "Also here" << std::endl;
      alpha = 0.5;
    }
    res(0) = alpha*(R(2,1)-R(1,2));
    res(1) = alpha*(R(0,2)-R(2,0));
    res(2) = alpha*(R(1,0)-R(0,1));
  }
  return res;
}


Eigen::Matrix3d axisAngleToRotation(const Eigen::Vector3d& w)
{
  Eigen::Matrix3d R, S;
  Eigen::Vector3d axis;

  double angle = w.norm();
  //std::cout << "angle: " << angle << std::endl;
  axis = w.normalized();
  //std::cout << "axis normalized: " << axis.transpose() << std::endl;
  S = skew(axis);
  //std::cout << "skew axis:\n " << S << std::endl;
  
  R = Eigen::Matrix3d::Identity() + sin(angle)*S + (1-cos(angle))*S*S;

  // double ca = cos(angle);
  // double sa = sin(angle);
  
  // R = sa*skew(axis);

  // for i in xrange(3):
  //     for j in xrange(3):
  //         R[i*3+j] += axis[i]*axis[j]*(1.-cm)
  // R[0] += cm
  // R[4] += cm
  // R[8] += cm
  
  return R;
}


Eigen::Matrix3d rotationMatrix(const char& axis,
                               const double& angle)
{
  double ca = cos(angle);
  double sa = sin(angle);
  Eigen::Matrix3d res;

  if (axis=='x')
    res << 1, 0, 0, 0, ca, -sa, 0, sa, ca;
  else if (axis=='y')
    res << ca, 0, sa, 0, 1, 0, -sa, 0, ca;
  else if (axis=='z')
    res << ca, -sa, 0, sa, ca, 0, 0, 0, 1;
  else {
    std::cerr << "rotationMatrix: Valid options for axis are only x, y, z" 
              << std::endl;
    res = Eigen::Matrix3d::Identity();
  }
  return res;
}
