#include <osik-control/kine-task.hpp>


namespace osik{

KineTask::KineTask(RobotModel* model,
                   const std::string& taskName,
                   const double& gain)
  :
  rmodel_(model),
  name_(taskName),
  gain_(gain),
  weight_(1.0),
  adaptiveGain_(false),
  lmax_(gain),
  lmin_(gain),
  k_(0.0)
{
  ndof_ = model->ndof();
}


KineTask::~KineTask()
{
  delete rmodel_;
}


void KineTask::setName(const std::string& taskName)
{
  name_ = taskName;
}


std::string KineTask::getName() const
{
  return name_;
}


void KineTask::setGain(const double& gain)
{
  // Set a constant gain
  adaptiveGain_ = false;
  gain_ = gain;
}


void KineTask::setAdaptiveGain(const double& max_gain, 
                               const double& min_gain, 
                               const double& rate_descent)
{
  // Set an adaptive gain
  adaptiveGain_ = true;
  std::cout << "Task " << name_ << ": Using adaptive gain" << std::endl;
  // Set the gains
  lmax_ = max_gain;
  lmin_ = min_gain;
  k_ = rate_descent;
  // The gain is set to the minimum gain
  gain_ = lmin_;
}



double KineTask::getGain(const double& error) 
{
  if (adaptiveGain_)
  {
    gain_ = (lmax_-lmin_)*exp(-k_*error)+lmin_;
  }
  return gain_;
}


void KineTask::setDesiredValue(const Eigen::Ref<const Eigen::VectorXd>& desiredValue)
{
  // std::cout << "set_desired" << std::endl;
  xdes_ = desiredValue;
  // Reset the error sum
  esum_ = Eigen::VectorXd::Zero(xdes_.size());
}


void KineTask::getDesiredValue(Eigen::VectorXd& desiredValue)
  const
{
  desiredValue = xdes_;
  // std::cout<<"set_desired"<<std::endl;
}


void KineTask::setWeight(const double& weight)
{
  weight_ = weight;
}


double KineTask::getWeight()
  const
{
  return weight_;
}


void KineTask::keep(const Eigen::VectorXd& q,
                    const double& gain)
{
  Eigen::VectorXd config;                                                          

  setGain(gain);
  getSensedValue(q, config);                                         
  setDesiredValue(config);                                                 
}


void KineTask::getTaskBounds(const Eigen::VectorXd& q,
                             Eigen::VectorXd& bound_min,
                             Eigen::VectorXd& bound_max)
{
  getDerivError(q, bound_min);
  bound_max = bound_min;
}


}
