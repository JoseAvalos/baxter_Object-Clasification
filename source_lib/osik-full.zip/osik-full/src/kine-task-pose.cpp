#include <osik-control/kine-task-pose.hpp>
#include <osik-control/math-tools.hpp>


namespace osik{


KineTaskPose::KineTaskPose(RobotModel* model,
                           const unsigned int& linkNum, 
                           const std::string& taskType,
                           const std::string& taskName)
  :
  KineTask(model, taskName),
  linkNum_(linkNum)
{
  localpos_ = Eigen::Vector3d::Zero();
  
  if (!taskType.compare("position"))
  {
    type_ = POSITION;
    std::cerr << "Type position" << std::endl;
  }
  else if (!taskType.compare("orientation"))
  {
    type_ = ORIENTATION;
    std::cerr << "Type orientation" << std::endl;
  }
  else if (!taskType.compare("pose"))
  {
    type_ = FULLPOSE;
    std::cerr << "Type Pose" << std::endl;
  }
  else
    std::cerr << "Unknown task type" << std::endl;
}


void KineTaskPose::getSensedValue(const Eigen::VectorXd& q,
                                  Eigen::VectorXd& xsensed)
  const
{
  if (type_ == POSITION)
    xsensed = rmodel_->linkPosition(q, linkNum_, localpos_);
  if (type_ == ORIENTATION)
    xsensed = rmodel_->linkOrientation(q, linkNum_);
  if (type_ == FULLPOSE)
    xsensed = rmodel_->linkPose(q, linkNum_, localpos_);
}


void KineTaskPose::getJacobian(const Eigen::VectorXd& q, 
                               Eigen::MatrixXd& Jacobian)
  const
{
  if (type_ == POSITION)
    Jacobian = rmodel_->linearJacobian(q, linkNum_, localpos_);
  else if (type_ == ORIENTATION)
    Jacobian = rmodel_->angularJacobian(q, linkNum_);
  else if (type_ == FULLPOSE)
  {
    Jacobian = rmodel_->geometricJacobian(q, linkNum_, localpos_);
    // Added for task jacobian using rpy
    Eigen::VectorXd xsensed;
    Eigen::Matrix3d Tinv;
    getSensedValue(q, xsensed);
    double r=xsensed(3), p=xsensed(4), y=xsensed(5);
    Tinv << cos(y)/cos(p), sin(y)/cos(p), 0,
      -sin(y), cos(y), 0,
      cos(y)*tan(p), tan(p)*sin(y), 1;
    Jacobian.bottomRows(3) = Tinv*Jacobian.bottomRows(3);
  }
}


void KineTaskPose::getDerivError(const Eigen::VectorXd& q, 
                                 Eigen::VectorXd& de)
{
  Eigen::VectorXd xsensed, xdes, error;
  getDesiredValue(xdes);
  getSensedValue(q, xsensed);
  if (type_ == POSITION)
  {
    error = xsensed-xdes;
    de = -getGain(error.norm())*error;
  }
  else if (type_ == ORIENTATION)
  {
    Eigen::Matrix3d R;
    Eigen::Vector3d w;
    R = RPYToRotation(xsensed).transpose()*RPYToRotation(xdes);
    //R = RPYToRotation(xsensed)*RPYToRotation(xdes).transpose();
    error = rotationToAxisAngle(R);
    // error = xsensed-xdes;
    de = getGain(error.norm())*error;
  }
  else if (type_ == FULLPOSE)
  {
    de.resize(6);
    error = xsensed.head(3)-xdes.head(3);
    de.head(3) = -getGain(error.norm())*error;

    Eigen::Matrix3d R;
    Eigen::Vector3d w;

    // R = RPYToRotation(xsensed.tail(3)).transpose()*RPYToRotation(xdes.tail(3));
    // //R = RPYToRotation(xsensed.tail(3))*RPYToRotation(xdes.tail(3)).transpose();
    // error = rotationToAxisAngle(R);
    // std::cout << "error: " << error.transpose() << std::endl;
    // std::cout << "xsensed: " << xsensed.transpose() << std::endl;
    // std::cout << "xdes: " << xdes.transpose() << std::endl;

    error = xsensed.tail(3)-xdes.tail(3);
    de.tail(3) = getGain(error.norm())*error;
  }
}

// unsigned int KineTaskPose::getTaskSize()
// {
//   return xdes_.size();
// }

// void KineTaskPose::getIntegralError(const Eigen::VectorXd& q,
//                                 Eigen::VectorXd& eint)
// {
//   Eigen::VectorXd xsensed, xdes;
//   getDesiredValue(xdes);
//   getSensedValue(q, xsensed);
//   esum_ = esum_ + (xsensed-xdes);
//   eint = -0.05*(esum_);
// }

}


// void KineTaskPose::getJacobian(const Eigen::VectorXd& q, 
//                            Eigen::MatrixXd& Jacobian)
// {
//   // TODO: Check that the Jacobian is initially set to zero
//   if (type_ == POSITION){
//     // Jacobian.resize(3,ndof_);
//     // Jacobian.setZero(); // VERY IMPORTANT FOR THE JACOBIAN!!!
//     // //CalcPointJacobian(*model_, q, linkNum_, localpos_, Jacobian, false);
//     // CalcPointJacobian(*model_, q, linkNum_, localpos_, Jacobian, true);

//     Eigen::Vector3d xbody, xbase;
    
//     xbody = CalcBodyToBaseCoordinates(*model_, q.tail(ndof_), linkNum_, 
//                                       localpos_, true);
//     xbase = CalcBodyToBaseCoordinates(*model_, q.tail(ndof_), 0, 
//                                       localpos_, true);
    
//     Eigen::MatrixXd Jxyz, Jffv;
//     Jxyz.resize(3,ndof_);
//     Jxyz.setZero(); // VERY IMPORTANT FOR THE JACOBIAN!!!
//     //CalcPointJacobian(*model_, q, linkNum_, localpos_, Jacobian, false);
//     CalcPointJacobian(*model_, q.tail(ndof_), linkNum_, localpos_, Jxyz);

//     Jacobian.resize(3,6+ndof_);
//     //Jacobian.topLeftCorner(3,3) = Eigen::MatrixXd::Identity(3,3);
//     Jacobian.leftCols(3) = Eigen::MatrixXd::Identity(3,3);
//     Jacobian.middleCols(3,3) = skew(xbase-xbody);
//     Jacobian.rightCols(ndof_) = Jxyz;
    
//     // std::cout << "qdes" << q.transpose() << std::endl;
//     // std::cout << "rwrist: " << linkNum_ << std::endl;
//     // std::cout << "localpos: " << localpos_.transpose() << std::endl;
//   }
//   else if (type_ == ORIENTATION)
//     std::cout << "TODO" << std::endl;
//   else if (type_ == FULLPOSE)
//     std::cout << "TODO" << std::endl;
//   // TODO: Use CalcBodySpatialJacobian for the orientation
// }
