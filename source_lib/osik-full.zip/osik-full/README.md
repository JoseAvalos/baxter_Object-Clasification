osik-control - Operational Space Inverse Kinematics Control


Introduction
============

osik-control is a C++ library that allows the generation of whole-body motion
for multi-articulated robots using inverse kinematics. It is based upon the
Rigid Body Dynamics Library (RBDL).

This package is embedding qpOASES and RBDL for ease of installation. For more
information about these packages, please refer to their respective projects.

Setup: Building and Installation
================================

The osik-control library uses qpOASES to solve QPs and RBDL for Rigid Body
algorithms. To compile these libraries and install them in the system use:

    cd ext
    ./install-ext  INSTALL_PREFIX  ADD_TO_BASH

where INSTALL_PREFIX is the path where the libraries will be installed (for
example, it can be replaced with ~/devel/install). ADD_TO_BASH is optional and
if included adds the pkg-config path to ~/.bashrc.

The osik-control library is then built using CMake. To compile the library in a
separate directory use:

    cd ..
    mkdir build; cd build
    source ~/.bashrc
    cmake .. -DCMAKE_INSTALL_PREFIX=install_prefix
    make

where install_prefix is the path where the library will be installed (for
example, it can be replaced with ~/devel/install). Please note that CMake
produces a `CMakeCache.txt` file which should be deleted to reconfigure a
package from scratch. To install the library use:
    
    make install

The documentation is contained in the code and can be extracted using
doxygen. To generate it, use:

    make doc

This will generate documentation in build/doc/doxygen-html. To see it, launch
index.html with your favorite browser.


### Dependencies

The osik-control library depends on the following libraries which have to be
available on your machine.

 - Libraries:
   - Eigen (>=3.2)
 - System tools:
   - CMake (>=2.8)
   - pkg-config
   - usual compilation tools (GCC/G++, make, etc.)


