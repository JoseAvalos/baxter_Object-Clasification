#ifndef OSIK_KINEMATIC_SOLVER_NS_H
#define OSIK_KINEMATIC_SOLVER_NS_H

#include <osik-control/kine-solver.hpp>

namespace osik
{

/**
 * Kinematic Solver using projections onto nullspaces
 */

class KineSolverNS :
  public KineSolver
{
public:
  
  /** 
   * Constructor
   * @param[in] rmodel Pointer to the robot model
   * @param[in] qinit Initial joint configuration
   * @param[in] dt control time (default is 10ms)
   */
  KineSolverNS(RobotModel* rmodel,
               const Eigen::VectorXd& qinit, 
               const double& dt=0.010);
  
  /** 
   * Solve for the kinematics using nullspace projections. The system is solved
   * in a prioritized way getting the desired position control for the given
   * configuration through projections onto the nullspaces of tasks with higher
   * priorities.
   *
   * @param[in] q current joint generalized configuration
   * @param[out] qdes joint position control (including free floating base, if
   *                  there is one)
   */
  void getPositionControl(const Eigen::VectorXd& q,
                          Eigen::VectorXd& qdes);

};

}

#endif
