#ifndef OSIK_CONSTANTS_HPP
#define OSIK_CONSTANTS_HPP


namespace osik {
  
  /// Numerical value of infinity
  const double INFTY = 1.0e20;

}


#endif
