#ifndef OSIK_MATH_TOOLS_H
#define OSIK_MATH_TOOLS_H

#include <Eigen/Dense>

/** 
 * @brief Compute the Moore-Penrose pseudoinverse
 * @param[in] input_mat Input matrix
 * @param[out] pseudo_inv_mat Pseudo inverse of the input matrix
 * @param[in] pinvtoler Tolerance for discarding null singular values
 */
void pinv(const Eigen::MatrixXd& input_mat, 
          Eigen::MatrixXd& pseudo_inv_mat, 
          const double& pinvtoler = 1.0e-6);

/**
 * Skew-symmetric matrix from vector
 * @param[in] w Input 3D vector
 * @return Skew symmetric matrix of w
 */
Eigen::Matrix3d skew(const Eigen::Vector3d& w);

/** 
 * Convert from roll pitch yaw to rotation matrix. Note that the roll is about
 * the 'x' axis, the pitch about the 'y' axis and the yaw about the 'z' axis.
 *
 * @param[in] rpy roll, pitch yaw angles \f$(\varphi_r,\varphi_p,\varphi_y)\f$
 * @return equivalent rotation matrix given by
 *         \f$R_z(\varphi_y)R_y(\varphi_p)R_x(\varphi_r)\f$
 * @see rotationToRPY()
 */
Eigen::Matrix3d RPYToRotation(const Eigen::Vector3d& rpy);


/** 
 * Convert a rotation matrix to roll, pitch, yaw angles. Note that roll is
 * about the 'x' axis, pitch about the 'y' axis and yaw about the 'z' axis.
 * 
 * @param[in] R rotation matrix \f$R \in SO(3)\f$
 * @return roll, pitch yaw angles \f$(\varphi_r,\varphi_p,\varphi_y)\f$
 * @see RPYToRotation()
 */
Eigen::Vector3d rotationToRPY(const Eigen::Matrix3d& R);

/** 
 * Convert a rotation matrix to the axis/angle representation. This
 * representation is \f$w=(w_x,w_y,w_z)\f$ where the rotation angle is
 * \f$\theta=\Vert w \Vert\f$ and the unitary rotation axis is
 * \f$\frac{w}{\Vert w \Vert}\f$. Note that \f$R = e^{w}\f$.
 * 
 * @param[in] R rotation matrix \f$R \in SO(3)\f$
 * @return axis/angle \f$w\f$. 
 * @see rotationToAxisAngle()
 */
Eigen::Vector3d rotationToAxisAngle(const Eigen::Matrix3d& R);


/** 
 * Convert an axis/angle representation to a rotation matrix. The axis/angle is
 * given as a vector \f$w=(w_x,w_y,w_z)\f$ where the rotation angle is
 * \f$\theta=\Vert w \Vert\f$ and the unitary axis is \f$\frac{w}{\Vert w
 * \Vert}\f$.
 * 
 * @param w axis/angle vector \f$w\f$
 * @return rotation matrix
 * @see axisAngleToRotation()
 */
Eigen::Matrix3d axisAngleToRotation(const Eigen::Vector3d& w);

/** 
 * Get a rotation matrix from an angle about an axis. This function is
 * specialized in rotations about 'x', 'y' and 'z' only.
 *
 * @param[in] axis axis of rotation. It can be 'x', 'y', 'z'
 * @param[in] angle angle of rotation (in radians).
 * @return rotation matrix
 */
Eigen::Matrix3d rotationMatrix(const char& axis,
                               const double& angle);



#endif
