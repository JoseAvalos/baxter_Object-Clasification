#ifndef OSIK_KINEMATIC_TASK_POSE_H
#define OSIK_KINEMATIC_TASK_POSE_H

#include <osik-control/kine-task.hpp>


namespace osik{

/**
 * Kinematic task for 6D placement. This task can control the position,
 * orientation and full pose of an operational point.
 */
class KineTaskPose : 
  public KineTask
{
public:

  /** 
   * @brief Constructor
   * @param[in] model robot model
   * @param[in] linkNum link number to be controlled
   * @param[in] taskType it can be "position", "orientation" or "pose"
   * @param[in] taskName name for the task
   */
  KineTaskPose(RobotModel* model,
               const unsigned int& linkNum, 
               const std::string& taskType,
               const std::string& taskName = "6DTask");
  
  /* Virtual functions */
  void getSensedValue(const Eigen::VectorXd& q,
                      Eigen::VectorXd& xsensed) const;
  // TODO: Check this eigen or eigen ref????
  void getJacobian(const Eigen::VectorXd& q, 
                   Eigen::MatrixXd& Jacobian) const;
  /** 
   * Get the derivative of the task error. This task uses: \f$\dot e=-\lambda
   * e\f$ where \f$e=x-x^*\f$
   * @param[in] q Joint generalized configuration
   * @param[out] de derivative of the task error
   */
  void getDerivError(const Eigen::VectorXd& q, 
                     Eigen::VectorXd& de);

  // void getIntegralError(const Eigen::VectorXd& q,
  //                       Eigen::VectorXd& eint);

  // unsigned int getTaskSize();

private:

  /// Link number
  unsigned int linkNum_;
  /// Local position with respect to the link frame
  Eigen::Vector3d localpos_;
  /// Indicator of task type
  enum PoseType{
    POSITION=0,
    ORIENTATION,
    FULLPOSE
  };
  /// Task type (POSITION, ORIENTATION or FULLPOSE)
  PoseType type_;
};

}

#endif
