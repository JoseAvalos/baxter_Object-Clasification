#ifndef OSIK_KINEMATIC_SOLVER_H
#define OSIK_KINEMATIC_SOLVER_H

#include <osik-control/kine-task.hpp>


namespace osik{

/**
 * Base class for inverse kinematic solvers. These solvers give a velocity
 * control law, based upon differential inverse kinematics, which is then
 * integrated to obtain a position control law.
 */
class KineSolver
{
public:

  /** 
   * Constructor
   * @param[in] rmodel Robot model
   * @param[in] qinit Initial joint generalized configuration
   * @param[in] dt control time
   */
  KineSolver(RobotModel* rmodel,
             const Eigen::VectorXd& qinit, 
             const double& dt);
  
  /**
   * Destructor
   */
  ~KineSolver();

  /** 
   * Push a task into the stack of tasks
   * @param[in] task Pointer to the kinematic task
   */
  void pushTask(KineTask* task);

  /** 
   * Remove the last added task (pop) from the stack of tasks
   */
  void popTask();

  /** 
   * Remove a task from the stack of tasks using the task name. If two or more
   * tasks have the same name, it removes the first one added to the stack.
   * @param[in] taskName Name of the task to be removed
   */
  void removeTask(const std::string& taskName);

  /** 
   * Get the stack containing pointers to the currently existing tasks
   * @param stack_tasks stack of tasks
   */
  void getTaskStack(std::vector< KineTask* >& stack_tasks);

  /**
   * Solve the system and get the desired position control for the given 
   * configuration 
   * @param[in] q current configuration
   * @param[out] qdes joint control
   */
  virtual void getPositionControl(const Eigen::VectorXd& q,
                                  Eigen::VectorXd& qdes) = 0;

  //KinematicTask getTaskByName(const std::string& taskName);


protected:

  /// Robot Model
  RobotModel* rmodel_;
  /// Discretization (control) time
  double dt_;
  /// Desired value for the joints
  Eigen::VectorXd qdes_;  //  (TODO: check this name)
  /// Stack of Tasks
  std::vector< KineTask* > taskStack_;
  /// Number of degrees of freedom
  unsigned int ndof_;

};

}

#endif

