#ifndef ROBOT_MODEL_H
#define ROBOT_MODEL_H

#include <rbdl/rbdl.h>

/**
 * Model of the robot parsing rbdl
 * 
 */
class RobotModel
{
  
public:
  /**
   * Constructor
   */
  RobotModel();

  /**
   * Destructor
   */
  ~RobotModel();
  
  /** 
   * Load the URDF model
   * @param[in] model_name path to the urdf describing the robot
   * @param[in] has_floating_base indicates that the robot has a floating base
   * @return true if successfully loaded
   */
  bool loadURDF(const std::string& model_name,
                const bool& has_floating_base = true);
  
  /** 
   * Get total number of degrees of freedom. It includes the floating base, if
   * the robot has one, otherwise, it is equivalent to ndof_actuated().
   * @return degrees of freedom
   */
  unsigned int ndof() const;

  /** 
   * Get number of actuated degrees of freedom. It excludes the floating base.
   * @return actuated degrees of freedom
   */
  unsigned int ndof_actuated() const;

  /** 
   * Get the joint names. It does not include the floating base. 
   * @return joint names
   */
  std::vector<std::string> jointNames() const;

  /** 
   * Get the maximum joint angluar limits. It does not include the robot
   * floating base.
   * @return joint angular limits (maximum)
   */
  std::vector<double> jointMaxAngularLimits() const;
  
  /** 
   * Get the minimum joint angluar limits. It does not include the robot
   * floating base.
   * @return joint angular limits (minimum)
   */
  std::vector<double> jointMinAngularLimits() const;
  
  /** 
   * Get the joint velocity limits. It does not include the floating base.
   * @return joint velocity limits (maximum)
   */
  std::vector<double> jointVelocityLimits() const;

  /** 
   * Get the link names and IDs.
   * @param[out] link_names link names
   * @param[out] link_id link id (corresponding to the respective link name)
   */
  void linkNames(std::vector<std::string>& link_names, 
                 std::vector<unsigned int>& link_ids) const;
  
  /** 
   * Get the position of a point (\f$x \in \mathbb{R}^3\f$) in a link with
   * respect to the world frame. If the robot does not have a floating base,
   * the world frame coincides with the robot base frame.
   *
   * @param[in] q generalized joint configuration (including floating base, if
   *             the robot has one)
   * @param[in] link_number link number for which the position will be computed
   * @param[in] local_pos point with respect to the link frame (offset).
   * @return the position \f$(x.y.z)\f$ with respect to the world frame
   */
  Eigen::Vector3d linkPosition(const Eigen::VectorXd& q, 
                               const unsigned int& link_number,
                               const Eigen::Vector3d& local_pos) const;

  /** 
   * Get the orientation of a link with respect to the world frame. If the
   * robot does not have a floating base, the world frame coincides with the
   * robot base frame.
   *
   * @param[in] q generalized joint configuration (including floating base, if
   *              the robot has one)
   * @param[in] link_number link number for which the orientation will be
   *                        computed
   * @return the orientation (roll, pitch, yaw) with respect to the world frame
   */
  Eigen::Vector3d linkOrientation(const Eigen::VectorXd& q,
                                  const unsigned int& link_number) const;


  /** 
   * Get the pose of a link with respect to the world frame. If the robot does
   * not have a floating base, the world frame coincides with the robot base
   * frame.
   * 
   * @param q generalized joint configuration (including floating base, if the
   *          robot has one)
   * @param link_number link number for which the pose will be computed
   * @param local_pos point with respect to the link frame (offset)
   * @return the pose \f$(x,y,z,r_x,r_y,r_z)\f$
   */
  Eigen::VectorXd linkPose(const Eigen::VectorXd& q,
                           const unsigned int& link_number,
                           const Eigen::Vector3d& local_pos) const;
  
  /** 
   * Get the Jacobian corresponding to the linear velocity. That is, \f$J_{v}
   * \in \mathbb{R}^{3 \times n}\f$ such that \f$v = J_{v} \dot q\f$ where \f$v
   * \in \mathbb{R}^3\f$ is the linear velocity, \f$\dot q\f$ is the
   * generalized joint velocity, and \f$n\f$ is the total number of degrees of
   * freedom (including the free floating base, if the robot has one).
   * 
   * @param[in] q current generalized joint configuration (including floating
   *              base, if the robot has one)
   * @param[in] link_number link number for which the Jacobian will be computed
   * @param[in] local_pos point with respect to the link
   * @return linear velocity Jacobian \f$J_{v}\f$
   */
  Eigen::MatrixXd linearJacobian(const Eigen::VectorXd& q, 
                                 const unsigned int& link_number,
                                 const Eigen::Vector3d& local_pos) const;

  /** 
   * Get the Jacobian corresponding to the angular velocity. That is,
   * \f$J_{\omega} \in \mathbb{R}^{3 \times n}\f$ such that \f$\omega =
   * J_{\omega} \dot q\f$ where \f$\omega \in \mathbb{R}^3\f$ is the angular
   * velocity, \f$\dot q\f$ is the generalized joint velocity, and \f$n\f$ is
   * the total number of degrees of freedom (including the free floating base,
   * if the robot has one).
   * 
   * @param[in] q current generalized joint configuration (including floating
   *              base, if the robot has one)
   * @param[in] link_number link number for which the Jacobian will be computed
   * @return angular velocity Jacobian \f$J_{\omega}\f$
   */
  Eigen::MatrixXd angularJacobian(const Eigen::VectorXd& q, 
                                  const unsigned int& link_number) const;
  
  /** 
   * Get the full geometric Jacobian. That is, \f$J = \begin{bmatrix}J_v \\
   * J_{\omega}\end{bmatrix} \in \mathbb{R}^{6 \times n}\f$ such that \f$
   * \begin{bmatrix}v \\ \omega\end{bmatrix} = J \dot q\f$ where \f$v \in
   * \mathbb{R}^3\f$ is the linear velocity, \f$\omega \in \mathbb{R}^3\f$ is
   * the angular velocity, \f$\dot q\f$ is the generalized joint velocity, and
   * \f$n\f$ is the total number of degrees of freedom (including the free
   * floating base, if the robot has one).
   * 
   * @param[in] q current generalized joint configuration (including floating
   *              base, if the robot has one)
   * @param[in] link_number link number for which the Jacobian will be computed
   * @param[in] local_pos point with respect to the link
   * @return geometric Jacobian \f$\begin{bmatrix}J_v \\
   *         J_{\omega}\end{bmatrix}\f$
   */
  Eigen::MatrixXd geometricJacobian(const Eigen::VectorXd& q, 
                                    const unsigned int& link_number,
                                    const Eigen::Vector3d& local_pos) const;
  
  /** 
   * Get information about whether or not a floating base exists
   * @return true if the robot model has a floating base
   */
  bool hasFloatingBase() const;

private:

  /// Internal RBDL model
  RigidBodyDynamics::Model* rmodel_;
  /// Indicator of floating base
  bool has_floating_base_;
  /// Joint names
  std::vector<std::string> jnames_;
  /// Joint angular limits (minimum) for revolute joints
  std::vector<double> qmin_;
  /// Joint angular limits (maximum) for revolute joints
  std::vector<double> qmax_;
  /// Joint velocity limits (maximum) for revolute joints
  std::vector<double> dqmax_;
};


#endif
